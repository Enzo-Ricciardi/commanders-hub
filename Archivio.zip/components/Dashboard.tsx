
import React from 'react';
import { CommanderProfile } from './widgets/CommanderProfile';
import { ShipStatus } from './widgets/ShipStatus';
import { SystemMap } from './widgets/SystemMap';
import { GalnetNews } from './widgets/GalnetNews';
import { MissionPlanner } from './widgets/MissionPlanner';
import { ActiveMissions } from './widgets/ActiveMissions';
import { MaterialsInventory } from './widgets/MaterialsInventory';
import { FleetOverview } from './widgets/FleetOverview';
import { GameData } from '../types';
import { ExplorationLog } from './widgets/ExplorationLog';

interface DashboardProps {
    gameData: GameData;
}

export const Dashboard: React.FC<DashboardProps> = ({ gameData }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
      <CommanderProfile commander={gameData.commander} />
      <ShipStatus ship={gameData.ship} />
      <SystemMap system={gameData.system} />
      <GalnetNews />
      <ActiveMissions missions={gameData.missions} />
      <FleetOverview storedShips={gameData.storedShips} fleetCarrier={gameData.fleetCarrier} />
      <div className="md:col-span-2 lg:col-span-2">
        <MaterialsInventory materials={gameData.materials} />
      </div>
      <div className="md:col-span-2 lg:col-span-3">
        <MissionPlanner ship={gameData.ship} />
      </div>
      <div className="md:col-span-2 lg:col-span-1">
        <ExplorationLog scans={gameData.explorationScans} />
      </div>
    </div>
  );
};