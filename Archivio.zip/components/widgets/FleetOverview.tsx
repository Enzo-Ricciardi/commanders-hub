
import React from 'react';
import { DataCard } from '../DataCard';
import { StoredShip, FleetCarrier } from '../../types';
import { ShipyardIcon } from '../icons';
import { useLanguage } from '../../context/LanguageContext';

interface FleetOverviewProps {
  storedShips: StoredShip[];
  fleetCarrier?: FleetCarrier;
}

export const FleetOverview: React.FC<FleetOverviewProps> = ({ storedShips, fleetCarrier }) => {
    const { t } = useLanguage();
    return (
        <DataCard title="fleetOverviewTitle" icon={<ShipyardIcon />} className="h-[26rem]">
            <div className="flex flex-col h-full">
                {fleetCarrier && (
                    <div className="p-3 bg-gradient-to-tr from-orange-900/40 to-orange-800/20 rounded-md border-2 border-orange-500/50 mb-3 flex-shrink-0">
                        <h4 className="font-orbitron text-lg text-orange-300">{fleetCarrier.name}</h4>
                        <p className="text-sm text-gray-400 font-mono mb-2">{fleetCarrier.callsign}</p>
                        <p className="text-sm"><span className="text-gray-400">{t('locationLabel')}:</span> {fleetCarrier.location}</p>
                        <p className="text-sm"><span className="text-gray-400">{t('carrierTritiumLabel')}:</span> {fleetCarrier.fuel.tritium.toLocaleString()} / {fleetCarrier.fuel.capacity.toLocaleString()} T</p>
                        <p className="text-sm"><span className="text-gray-400">{t('carrierBalanceLabel')}:</span> {fleetCarrier.balance.toLocaleString()} CR</p>
                        <div className="mt-2">
                            <p className="text-xs text-gray-400 mb-1">{t('carrierServicesLabel')}:</p>
                            <div className="flex flex-wrap gap-1">
                                {fleetCarrier.services.map(service => (
                                <span key={service} className="text-xs bg-gray-700 text-gray-300 px-2 py-0.5 rounded-full">{service}</span>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
                <div className="flex-grow flex flex-col min-h-0">
                    <h4 className="font-semibold text-gray-200 mb-1 flex-shrink-0">{t('storedShipsLabel')}</h4>
                    <div className="space-y-2 overflow-y-auto flex-grow pr-1">
                        {storedShips.length > 0 ? storedShips.map(ship => (
                            <div key={ship.id} className="p-2 bg-gray-900/50 rounded-md text-sm">
                                <p className="font-semibold text-white">{ship.name ? `${ship.name} (${ship.type})` : ship.type}</p>
                                <p className="text-gray-400">{ship.location}</p>
                            </div>
                        )) : <p className="text-gray-500 text-center pt-4">{t('noStoredShips')}</p>}
                    </div>
                </div>
            </div>
        </DataCard>
    )
};