
import React, { useState } from 'react';
import { DataCard } from '../DataCard';
import { LogIcon, SparkleIcon } from '../icons';
import { useLanguage } from '../../context/LanguageContext';
import { ExplorationScan } from '../../types';
import { generateExplorationLog } from '../../services/geminiService';

interface ExplorationLogProps {
  scans: ExplorationScan[];
}

export const ExplorationLog: React.FC<ExplorationLogProps> = ({ scans }) => {
  const { t } = useLanguage();
  const [selectedScanId, setSelectedScanId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [logContent, setLogContent] = useState<{ log: string; imageUrl: string } | null>(null);

  const handleGenerateLog = async () => {
    const selectedScan = scans.find(s => s.id === selectedScanId);
    if (!selectedScan) return;

    setIsLoading(true);
    setLogContent(null);

    const logPrompt = `As the captain of a starship in Elite Dangerous, write a creative and immersive captain's log entry based on the following scan data. Make it sound personal and reflective. Data: ${selectedScan.detailsForPrompt}`;
    const imagePrompt = `An awe-inspiring, cinematic digital painting of a scene from the game Elite Dangerous. The view is from the cockpit of a spaceship, looking out at the following vista: ${selectedScan.detailsForPrompt}. Focus on a sense of scale and wonder. High detail, 4k, sci-fi aesthetic.`;

    const result = await generateExplorationLog(logPrompt, imagePrompt);
    setLogContent(result);
    setIsLoading(false);
  };

  return (
    <DataCard title="explorationLogTitle" icon={<LogIcon />} className="h-[26rem]">
      <div className="flex flex-col h-full">
        <div className="mb-3">
          <h4 className="text-sm text-gray-400 mb-2">{t('recentScansLabel')}</h4>
          <div className="flex flex-col gap-1 max-h-24 overflow-y-auto pr-2">
            {scans.map(scan => (
              <button
                key={scan.id}
                onClick={() => setSelectedScanId(scan.id)}
                className={`w-full text-left p-2 text-sm rounded-md transition ${selectedScanId === scan.id ? 'bg-orange-500/30 ring-1 ring-orange-400' : 'bg-gray-900/50 hover:bg-gray-800/70'}`}
              >
                <p className="font-semibold text-gray-200">{scan.scanType}: {scan.bodyName}</p>
                <p className="text-xs text-gray-400">{scan.description}</p>
              </button>
            ))}
          </div>
        </div>

        <button 
          onClick={handleGenerateLog} 
          disabled={!selectedScanId || isLoading}
          className="w-full flex items-center justify-center bg-orange-600 hover:bg-orange-500 text-white font-bold py-2 px-4 rounded-md transition duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed mb-3"
        >
          <SparkleIcon />
          <span className="ml-2">{isLoading ? t('generatingLogButton') : t('generateLogButton')}</span>
        </button>

        <div className="flex-grow overflow-y-auto p-2 bg-gray-900/50 rounded-md border border-gray-700/50 min-h-0">
          {isLoading && (
            <div className="flex items-center justify-center h-full text-center text-gray-400">
              <div>
                <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-orange-500 mx-auto mb-3"></div>
                <p>{t('logGenerationLoading')}</p>
              </div>
            </div>
          )}
          {!isLoading && !logContent && (
            <div className="flex items-center justify-center h-full text-gray-500">
              <p>{t('selectScanPrompt')}</p>
            </div>
          )}
          {logContent && (
            <div className="space-y-4">
              {logContent.imageUrl && (
                <img src={logContent.imageUrl} alt={t('captainsLogTitle')} className="rounded-md object-cover w-full aspect-video border-2 border-orange-500/20" />
              )}
              <div>
                <h5 className="font-orbitron text-lg text-orange-400 mb-2">{t('captainsLogTitle')}: {scans.find(s => s.id === selectedScanId)?.bodyName}</h5>
                <p className="whitespace-pre-wrap text-sm text-gray-300">{logContent.log}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </DataCard>
  );
};
