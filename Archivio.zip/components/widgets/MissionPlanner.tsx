
import React, { useState } from 'react';
import { DataCard } from '../DataCard';
import { MissionIcon, SparkleIcon } from '../icons';
import { analyzeWithAI } from '../../services/geminiService';
import { Ship } from '../../types';
import { useLanguage } from '../../context/LanguageContext';

interface MissionPlannerProps {
    ship: Ship;
}

export const MissionPlanner: React.FC<MissionPlannerProps> = ({ ship }) => {
    const { t } = useLanguage();
    const [prompt, setPrompt] = useState(t('missionPlannerDefaultPrompt'));
    const [plan, setPlan] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleGeneratePlan = async () => {
        if (!prompt) return;
        setIsLoading(true);
        setPlan('');
        const fullPrompt = `As an expert Elite Dangerous mission planner, create a detailed, step-by-step plan for the following request. The commander is currently in a ${ship.type}. The plan should be realistic and include potential challenges and rewards. Here is the request: "${prompt}". My ship details are: ${JSON.stringify(ship)}`;
        const result = await analyzeWithAI(fullPrompt, true); // Use Pro model with thinking
        setPlan(result);
        setIsLoading(false);
    };

    return (
        <DataCard title="missionPlannerTitle" icon={<MissionIcon />} className="h-[26rem]">
            <div className="flex flex-col h-full">
                <div className="flex flex-col md:flex-row gap-2 mb-3">
                    <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder={t('missionPlannerPlaceholder')}
                        className="flex-grow bg-gray-900/80 border border-gray-600 rounded-md p-2 text-sm text-gray-200 focus:ring-orange-500 focus:border-orange-500 transition resize-none"
                        rows={2}
                    />
                    <button onClick={handleGeneratePlan} disabled={isLoading} className="flex items-center justify-center bg-orange-600 hover:bg-orange-500 text-white font-bold py-2 px-4 rounded-md transition duration-300 disabled:bg-gray-500 h-full">
                        <SparkleIcon />
                        <span className="ml-2">{isLoading ? t('thinkingButton') : t('generatePlanButton')}</span>
                    </button>
                </div>

                <div className="flex-grow overflow-y-auto p-3 bg-gray-900/50 rounded-md border border-gray-700/50">
                    {isLoading && !plan && (
                         <div className="flex items-center justify-center h-full">
                            <div className="text-center text-gray-400">
                                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500 mx-auto mb-4"></div>
                                <p>{t('missionPlannerLoading1')}</p>
                                <p>{t('missionPlannerLoading2')}</p>
                            </div>
                        </div>
                    )}
                    {plan && <div className="whitespace-pre-wrap text-sm text-gray-300">{plan}</div>}
                    {!isLoading && !plan && <p className="text-gray-500 text-center pt-8">{t('missionPlannerWaiting')}</p>}
                </div>
            </div>
        </DataCard>
    );
};
