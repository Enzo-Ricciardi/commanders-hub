import { onCall } from "firebase-functions/v2/https";
import { onRequest } from "firebase-functions/v2/https";
import * as admin from "firebase-admin";
import { logger } from "firebase-functions";
import { defineString } from "firebase-functions/params";
import axios from "axios";

import { getMockGameData } from "./mockData";
import { GameData } from "./types";

admin.initializeApp();

// Define configuration parameters
const frontierClientId = defineString("FRONTIER_CLIENT_ID");
const frontierClientSecret = defineString("FRONTIER_CLIENT_SECRET");

const FALLBACK_FRONTIER_CLIENT_ID = "db54bf88-2a8a-4d63-bfcc-638b44cdd982";
const FALLBACK_FRONTIER_CLIENT_SECRET = "66596cdb-a027-414a-acc4-9c5c39c13c1e";

const getFrontierClientId = (): string => {
  return (
    frontierClientId.value() ||
    process.env.FRONTIER_CLIENT_ID ||
    FALLBACK_FRONTIER_CLIENT_ID
  );
};

const getFrontierClientSecret = (): string => {
  return (
    frontierClientSecret.value() ||
    process.env.FRONTIER_CLIENT_SECRET ||
    FALLBACK_FRONTIER_CLIENT_SECRET
  );
};

// --- AUTHENTICATION FLOW ---

// =======================================================================================
// ACTION REQUIRED: UPDATE THESE VALUES AFTER YOUR FIRST DEPLOYMENT
// =======================================================================================
// Find your function region in the deployment output (e.g., "us-central1").
// const FUNCTION_REGION = "us-central1"; // Non più necessario, l'URL di redirect usa il dominio di hosting
// Find your project ID in the Cloud Shell prompt or Firebase console (e.g., "commanders-hub-12345").
const PROJECT_ID = "gen-lang-client-0452273955";
// =======================================================================================


// This is the URL that Frontier will redirect to after the user logs in.
// It is constructed from the values above.
// It must EXACTLY match the Redirect URI you set in the Frontier Developers Portal.
const REDIRECT_URI = `https://${PROJECT_ID}.web.app/frontiercallback`;

// Step 1: Redirect user to Frontier's login page
export const frontierAuth = onRequest({ cors: true }, (request, response) => {
  const clientId = getFrontierClientId();
  if (!clientId) {
    logger.error("Frontier Client ID is not configured.");
    response.status(500).send("Application is not configured correctly. Please contact support.");
    return;
  }

  const state = "random_string_for_security"; // In a real app, generate and validate this

  const authUrl = "https://auth.frontierstore.net/auth?" +
    `response_type=code&` +
    `client_id=${clientId}&` +
    `scope=auth%20capi&` +
    `state=${state}&` +
    `redirect_uri=${encodeURIComponent(REDIRECT_URI)}`;

  logger.info(`Redirecting user to Frontier for authentication. URI: ${REDIRECT_URI}`);
  response.redirect(authUrl);
});


// Step 2: Handle the callback from Frontier
export const frontierCallback = onRequest({ cors: true }, async (request, response) => {
  const code = request.query.code as string;
  const state = request.query.state as string;

  logger.info("Callback received", { code: code ? "***" : "missing", state, query: request.query });

  if (!code) {
    logger.error("Callback received without an authorization code.");
    response.status(400).send("Authentication failed: No authorization code provided.");
    return;
  }

  logger.info("Received authorization code from Frontier. Exchanging for token...");

  try {
    const clientId = getFrontierClientId();
    const clientSecret = getFrontierClientSecret();

    if (!clientId || !clientSecret) {
      logger.error("Frontier credentials are not configured in Firebase.");
      throw new Error("Server configuration error.");
    }

    // Manually construct the body string to ensure exact control over encoding
    const bodyParams = [
      `grant_type=authorization_code`,
      `code=${code}`,
      `redirect_uri=${encodeURIComponent(REDIRECT_URI)}`, // Explicitly encode for OAuth 2.0 compliance
      `client_id=${clientId}`,
      `client_secret=${clientSecret}`
    ].join('&');

    logger.info("Sending token request to Frontier with manual body:", {
      redirect_uri: REDIRECT_URI,
      client_id: clientId,
      grant_type: "authorization_code"
    });

    const tokenResponse = await axios.post(
      "https://auth.frontierstore.net/token",
      bodyParams,
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      },
    );

    const accessToken = tokenResponse.data.access_token;
    logger.info("Successfully obtained access token from Frontier.");

    // --- Test API call with the new token ---
    logger.info("Fetching profile data from Frontier CAPI...");
    const profileResponse = await axios.get("https://companion.orerve.net/profile", {
      headers: {
        "Authorization": `Bearer ${accessToken}`,
      },
    });

    logger.info("Successfully fetched profile data:", profileResponse.data);

    // Map profile to GameData
    const profile = profileResponse.data;
    const gameData = getMockGameData(); // Use as fallback for missing data

    // Map Commander data
    if (profile.commander) {
      gameData.commander.name = profile.commander.name || gameData.commander.name;
      gameData.commander.credits = profile.commander.credits || gameData.commander.credits;

      // Map ranks
      if (profile.commander.rank) {
        const rankNames = ['Harmless', 'Mostly Harmless', 'Novice', 'Competent', 'Expert', 'Master', 'Dangerous', 'Deadly', 'Elite'];
        const tradeRanks = ['Penniless', 'Mostly Penniless', 'Peddler', 'Dealer', 'Merchant', 'Broker', 'Entrepreneur', 'Tycoon', 'Elite'];
        const exploreRanks = ['Aimless', 'Mostly Aimless', 'Scout', 'Surveyor', 'Trailblazer', 'Pathfinder', 'Ranger', 'Pioneer', 'Elite'];

        gameData.commander.ranks.combat = rankNames[profile.commander.rank.combat] || gameData.commander.ranks.combat;
        gameData.commander.ranks.trade = tradeRanks[profile.commander.rank.trade] || gameData.commander.ranks.trade;
        gameData.commander.ranks.exploration = exploreRanks[profile.commander.rank.explore] || gameData.commander.ranks.exploration;
        gameData.commander.ranks.cqc = rankNames[profile.commander.rank.cqc] || gameData.commander.ranks.cqc;
      }
    }

    // Map current location
    if (profile.lastSystem) {
      gameData.commander.location = profile.lastSystem.name || gameData.commander.location;
      gameData.system.name = profile.lastSystem.name || gameData.system.name;
    }

    // Map current ship
    if (profile.ship) {
      gameData.ship.name = profile.ship.name || profile.ship.shipName || gameData.ship.name;
      gameData.ship.type = profile.ship.shipName || gameData.ship.type;

      if (profile.ship.fuel) {
        gameData.ship.fuel.current = profile.ship.fuel.FuelMain || gameData.ship.fuel.current;
        gameData.ship.fuel.capacity = profile.ship.fuel.FuelCapacity || gameData.ship.fuel.capacity;
      }

      if (profile.ship.cargo) {
        gameData.ship.cargo.current = profile.ship.cargo.count || 0;
        gameData.ship.cargo.capacity = profile.ship.cargo.capacity || gameData.ship.cargo.capacity;
      }

      gameData.ship.integrity = profile.ship.health?.hull || gameData.ship.integrity;
      gameData.ship.shields = profile.ship.health?.shield || gameData.ship.shields;
      gameData.ship.rebuyCost = profile.ship.value?.hull || gameData.ship.rebuyCost;
    }

    // Map stored ships
    if (profile.ships && Array.isArray(profile.ships)) {
      gameData.storedShips = profile.ships.map((ship: any, index: number) => ({
        id: ship.id || index,
        type: ship.name || 'Unknown',
        name: ship.shipName,
        location: ship.starsystem?.name || ship.station?.name || 'Unknown',
        value: ship.value?.hull || 0
      }));
    }

    // Map materials
    if (profile.materials) {
      const materials: any[] = [];

      if (profile.materials.Raw) {
        Object.entries(profile.materials.Raw).forEach(([name, count]) => {
          materials.push({ name, category: 'Raw', count: count as number, max: 300 });
        });
      }

      if (profile.materials.Manufactured) {
        Object.entries(profile.materials.Manufactured).forEach(([name, count]) => {
          materials.push({ name, category: 'Manufactured', count: count as number, max: 250 });
        });
      }

      if (profile.materials.Encoded) {
        Object.entries(profile.materials.Encoded).forEach(([name, count]) => {
          materials.push({ name, category: 'Encoded', count: count as number, max: 500 });
        });
      }

      if (materials.length > 0) {
        gameData.materials = materials;
      }
    }

    // Map active missions
    if (profile.missions && Array.isArray(profile.missions)) {
      gameData.missions = profile.missions.map((mission: any) => ({
        id: mission.MissionID?.toString() || Math.random().toString(),
        type: mission.LocalisedName || mission.Name || 'Unknown Mission',
        faction: mission.Faction || 'Unknown',
        destinationSystem: mission.DestinationSystem || 'Unknown',
        reward: mission.Reward || 0,
        isWing: mission.Wing || false,
        status: 'Active'
      }));
    }

    logger.info("Mapped game data:", {
      commanderName: gameData.commander.name,
      location: gameData.commander.location,
      shipType: gameData.ship.type,
      credits: gameData.commander.credits
    });

    // Respond to the user's browser with a script to save data and redirect
    response.status(200).send(`
      <html>
        <body style="background-color: #0c111a; color: #e5e7eb; display: flex; justify-content: center; align-items: center; height: 100vh; font-family: sans-serif;">
          <div style="text-align: center;">
            <h1 style="margin-bottom: 20px;">Authentication Successful</h1>
            <p>Loading Commander data...</p>
            <div style="margin-top: 20px; width: 40px; height: 40px; border: 4px solid #f97316; border-top: 4px solid transparent; border-radius: 50%; animation: spin 1s linear infinite; margin-left: auto; margin-right: auto;"></div>
          </div>
          <style>
            @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
          </style>
          <script>
            try {
              const data = ${JSON.stringify(gameData)};
              localStorage.setItem('commander_data', JSON.stringify(data));
              setTimeout(() => {
                window.location.href = '/';
              }, 1500);
            } catch (e) {
              console.error(e);
              document.body.innerHTML = '<h1>Error</h1><p>Failed to save game data.</p>';
            }
          </script>
        </body>
      </html>
    `);
  } catch (error) {
    logger.error("Error during token exchange or profile fetch:", error);
    if (axios.isAxiosError(error)) {
      logger.error("Axios error details:", error.response?.data);
    }
    response.status(500).send(`
       <html>
        <body style="font-family: sans-serif; background-color: #0c111a; color: #e5e7eb; text-align: center; padding-top: 50px;">
          <h1>Authentication Failed</h1>
          <p>There was an error connecting to the Frontier servers.</p>
          <p>Please try again later. Check the function logs for more details.</p>
        </body>
      </html>
    `);
  }
});


// --- MOCK DATA FLOW ---
// This function remains to allow UI testing without full authentication.
export const getGameData = onCall<unknown, Promise<GameData>>((request) => {
  logger.info("getGameData function was called for MOCK data", { auth: request.auth });
  const gameData = getMockGameData();
  return Promise.resolve(gameData);
});